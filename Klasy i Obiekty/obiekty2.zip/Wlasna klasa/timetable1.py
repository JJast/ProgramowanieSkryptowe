import math
from typing import List

from DeanerySystem import Term, Day
from action import Action
from lesson import Lesson, NeitherFullNorPartError


class Timetable1(object):
    """ Class containing a set of operations to manage the timetable """

    def __init__(self):
        self.lessonList = []

    ##########################################################
    def can_be_transferred_to(self, term: Term, full_time: bool) -> bool:
        """
Informs whether a lesson can be transferred to the given term

Parameters
----------
term : Term
    The term checked for the transferability
full_time : bool
    Full-time or part-time studies

Returns
-------
bool
    **True** if the lesson can be transferred to this term
"""
        try:
            if full_time != term.checkIfStationary():
                return False
        except NeitherFullNorPartError as e:
            return False

        for lesson in self.lessonList:
            if lesson.term.termday__ == term.termday__:
                lessonMinutesStart = lesson.term.hour * 60 + lesson.term.minute
                lessonMinutesStop = lessonMinutesStart + lesson.term.duration
                termMinutesStart = term.hour * 60 + term.minute
                termMinutesStop = termMinutesStart + term.duration
                if (lessonMinutesStart <= termMinutesStart < lessonMinutesStop) or (
                        lessonMinutesStart < termMinutesStop <= lessonMinutesStop):
                    return False
        return True

    ##########################################################

    def busy(self, term: Term) -> bool:
        """
Informs whether the given term is busy.  Should not be confused with ``can_be_transfered_to()``
since there might be free term where the lesson cannot be transferred.

Parameters
----------
term : Term
    Checked term

Returns
-------
bool
    **True** if the term is busy
        """
        for lesson in self.lessonList:
            if lesson.term == term:
                return True
        return False

    ##########################################################

    def put(self, lesson: Lesson) -> bool:
        """
Add the given lesson to the timetable.

Parameters
----------
lesson : Lesson
    The added  lesson

Returns
-------
bool
    **True**  if the lesson was added.  The lesson cannot be placed if the timetable slot is already occupied.
        """
        if self.can_be_transferred_to(lesson.term, lesson.full_time):
            self.lessonList.append(lesson)
            return True
        return False

    ##########################################################

    def parse(self, actions: List[str]) -> List[Action]:
        """
Converts an array of strings to an array of 'Action' objects.

Parameters
----------
actions:  List[str]
    A list containing the strings: "d-", "d+", "t-" or "t+"

Returns
-------
    List[Action]
        A list containing the values:  DAY_EARLIER, DAY_LATER, TIME_EARLIER or TIME_LATER
        """
        actionList = []
        for action in actions:
            if action == "d-":
                actionList.append(Action.DAY_EARLIER)
            elif action == "d+":
                actionList.append(Action.DAY_LATER)
            elif action == "t-":
                actionList.append(Action.TIME_EARLIER)
            elif action == "t+":
                actionList.append(Action.TIME_LATER)
            else:
                print("Undefined action: \n", action)
        return actionList

    ##########################################################

    def perform(self, actions: List[Action]):
        """
Transfer the lessons included in the timetable as described in the list of actions. N-th action should be sent the n-th lesson in the timetable.

Parameters
----------
actions : List[Action]
    Actions to be performed
        """
        lessonIndex = 0
        for action in actions:
            if action == Action.DAY_EARLIER:
                self.lessonList[lessonIndex].earlierDay()
            elif action == Action.DAY_LATER:
                self.lessonList[lessonIndex].laterDay()
            elif action == Action.TIME_EARLIER:
                self.lessonList[lessonIndex].earlierTime()
            elif action == Action.TIME_LATER:
                self.lessonList[lessonIndex].laterTime()
            lessonIndex =  (lessonIndex+1) % len(self.lessonList)

    ##########################################################

    def get(self, term: Term) -> Lesson:
        """
Get object (lesson) indicated by the given term.

Parameters
----------
term: Term
    Lesson date

Returns
-------
lesson: Lesson
    The lesson object or None if the term is free
        """
        for lesson in self.lessonList:
            if lesson.term.termday__ == term.termday__ and lesson.term == term:
                return lesson
        return None

    ##########################################################

    def __str__(self):
        maxLen = 12
        for lesson in self.lessonList:
            if len(lesson.name) > maxLen:
                maxLen = len(lesson.name)
        print(" " * 12, "*Poniedziałek*Wtorek      *Środa       *Czwartek    *Piątek      *Sobota      *Niedziela")
        print(" " * 12, "*" * 90)

        currHour = 8
        currMinute = 0
        for i in range(8):
            self.printTime(i)
            for currDay in Day:  # przechodz po dniach tygodnia
                currentTerm = Term(currDay, currHour, currMinute)
                lesson = self.get(currentTerm)
                if lesson is not None:
                    print("*", lesson.name.ljust(11), end="")
                    continue
                print("*"," " * 11, end="")
            print("\n"," " * 11, "*" * 90)
            currHour += 1
            currMinute += 30
            if currMinute == 60:
                currHour += 1
                currMinute = 0
        return ""

    @staticmethod
    def printTime(i: int):
        currentMinutesTime = 8 * 60 + 90 * i
        startHour = math.floor(currentMinutesTime / 60)
        startMinute = str(currentMinutesTime % 60).zfill(2)
        finishMinutesTime = currentMinutesTime + 90
        finishHour = math.floor(finishMinutesTime / 60)
        finishMinute = str(finishMinutesTime % 60).zfill(2)
        dateStr = "{}:{}-{}:{}".format(startHour, startMinute, finishHour, finishMinute)
        print(dateStr.ljust(13), end="")



if __name__ == '__main__':
    lesson = Lesson(Term(Day.WED, 14, 00), "Polski", "Krzysztof", 2)
    lesson1 = Lesson(Term(Day.SAT, 9, 30), "Angielski", "Krzysztof", 2)
    timetable = Timetable1()
    timetable.put(lesson)
    timetable.put(lesson1)
    print(timetable)

    actions = timetable.parse(["d-", "d+", "t-", "t+"])
    timetable.perform(actions)
    print(timetable)
